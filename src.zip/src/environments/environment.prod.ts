export const environment = {
  production: true,
  apiUrl: 'https://youApiEndpoint:port',
};
