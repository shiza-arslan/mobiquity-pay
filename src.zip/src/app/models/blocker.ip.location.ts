export const Config = {
  authConfig: {
    geoLocation: ['Dubai', 'India'],
    ipAddress: ['119.160.97.14', '119.160.57.147'],
  },
};
