import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mobiquity-pay-image-upload',
  templateUrl: './image-upload.component.html',
  styleUrls: ['./image-upload.component.scss'],
})
export class ImageUploadComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
