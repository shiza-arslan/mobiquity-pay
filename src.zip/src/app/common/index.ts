export { Config } from '../models/blocker.ip.location';
